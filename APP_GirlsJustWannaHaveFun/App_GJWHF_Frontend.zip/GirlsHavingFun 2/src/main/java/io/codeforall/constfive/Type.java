package io.codeforall.constfive;

public enum Type {

    BAR,
    NIGHTCLUB
}