package io.codeforall.constfive;

public enum Genre {

    TECHNO,
    JAZZ,
    ROCK,
    POP,
    MISC
}
