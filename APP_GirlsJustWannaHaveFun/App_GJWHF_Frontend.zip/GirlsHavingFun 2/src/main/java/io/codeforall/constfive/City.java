package io.codeforall.constfive;

public enum City {
    LISBON,
    PORTO
}
