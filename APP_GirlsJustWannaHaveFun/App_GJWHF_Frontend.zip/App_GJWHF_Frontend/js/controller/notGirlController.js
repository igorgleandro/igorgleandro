import notGirlView from '/js/view/notGirlView.js';

let questions = [];

async function init() {
    notGirlView.render();
}
export default {init};