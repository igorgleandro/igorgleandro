import router from "/js/router.js";

window.addEventListener("DOMContentLoaded", function () {
    console.log("DOM is loaded!");
    router.init();
});
