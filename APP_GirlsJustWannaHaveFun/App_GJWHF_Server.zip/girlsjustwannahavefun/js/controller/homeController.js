import homeView from '/js/view/homeView.js';

async function init() {
  homeView.render();
};

export default { init };
