package io.codeforall.constfive;

import junit.framework.TestCase;

public class RestGenericControllerTest extends TestCase {

}