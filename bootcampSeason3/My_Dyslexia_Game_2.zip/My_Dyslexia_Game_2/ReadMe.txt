_________________________________
----WECOllME TO <MY_DSYLEXIA>----
_________________________________

Hey folks, gather 'round, my Dyslexia is throwing a wild party in my brain lately...
So, lend me a hand unjumbling these words, would ya? Here's the deal:
Whoever unscrambles 5 words first gets to claim victory and eternal glory!

Pick a category, and I'll toss you a scrambled word. Your mission?
Unscramble it and crack the code! Easy peasy lemon squeezy!

Let's dive in and have a blast!

-Available for 2 Players.
-Set the desired Port number at the beginning of the jar File.

______________________________________________
Game made by: Igor Leandro and Andre Hortelao